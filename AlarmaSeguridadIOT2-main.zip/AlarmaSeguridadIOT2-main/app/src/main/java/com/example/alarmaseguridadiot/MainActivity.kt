package com.example.alarmaseguridadiot

import android.graphics.Color
import android.media.MediaPlayer
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class MainActivity : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth
    private lateinit var dbRef: DatabaseReference
    private var mediaPlayer: MediaPlayer? = null

    private lateinit var seccionLogin: LinearLayout
    private lateinit var seccionOperacion: LinearLayout
    private lateinit var tvEstadoAlarma: TextView
    private lateinit var etEmail: EditText
    private lateinit var etPassword: EditText
    private lateinit var btnLogin: Button
    private lateinit var btnActivarEmergencia: Button
    private lateinit var btnSilenciarRestablecer: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        auth = FirebaseAuth.getInstance()
        dbRef = FirebaseDatabase.getInstance("https://alarmaseguridadiot-892a5-default-rtdb.firebaseio.com/").getReference("alarmas/estado")

        seccionLogin = findViewById(R.id.seccionLogin)
        seccionOperacion = findViewById(R.id.seccionOperacion)
        tvEstadoAlarma = findViewById(R.id.tvEstadoAlarma)
        etEmail = findViewById(R.id.etEmail)
        etPassword = findViewById(R.id.etPassword)
        btnLogin = findViewById(R.id.btnLogin)
        btnActivarEmergencia = findViewById(R.id.btnActivarEmergencia)
        btnSilenciarRestablecer = findViewById(R.id.btnSilenciarRestablecer)

        configurarEventos()

        escucharEventosAlarma()
    }

    private fun configurarEventos() {
        btnLogin.setOnClickListener {
            val email = etEmail.text.toString().trim()
            val pass = etPassword.text.toString().trim()
            if (email.isNotEmpty() && pass.isNotEmpty()) {
                autenticarUsuario(email, pass)
            } else {
                Toast.makeText(this, "Complete todos los campos", Toast.LENGTH_SHORT).show()
            }
        }

        btnActivarEmergencia.setOnClickListener {
            cambiarEstadoAlarma(activa = true)
        }

        btnSilenciarRestablecer.setOnClickListener {
            cambiarEstadoAlarma(activa = false)
        }
    }

    private fun autenticarUsuario(email: String, pass: String) {
        auth.signInWithEmailAndPassword(email, pass)
            .addOnSuccessListener {
                Toast.makeText(this, "Autenticación exitosa", Toast.LENGTH_SHORT).show()
                seccionLogin.visibility = View.GONE
                seccionOperacion.visibility = View.VISIBLE
            }
            .addOnFailureListener { exception ->
                Toast.makeText(this, "Error: ${exception.message}", Toast.LENGTH_LONG).show()
            }
    }

    private fun cambiarEstadoAlarma(activa: Boolean) {
        val uid = auth.currentUser?.uid ?: "Desconocido"
        val datos = mapOf(
            "activa" to activa,
            "modificadoPor" to uid,
            "timestamp" to System.currentTimeMillis()
        )
        dbRef.setValue(datos)
    }

    private fun escucharEventosAlarma() {
        dbRef.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val estaActiva = snapshot.child("activa").getValue(Boolean::class.java) ?: false
                actualizarInterfazYAlerta(estaActiva)
            }

            override fun onCancelled(error: DatabaseError) {
                Toast.makeText(applicationContext, "Error: ${error.message}", Toast.LENGTH_SHORT).show()
            }
        })
    }

    private fun actualizarInterfazYAlerta(estaActiva: Boolean) {
        if (estaActiva) {
            tvEstadoAlarma.text = "¡ALARMA ACTIVADA - EMERGENCIA!"
            tvEstadoAlarma.setTextColor(Color.RED)
            reproducirSonidoAlarma()
        } else {
            tvEstadoAlarma.text = "Estado: Monitoreo Normal"
            tvEstadoAlarma.setTextColor(Color.parseColor("#16A34A"))
            detenerSonidoAlarma()
        }
    }

    private fun reproducirSonidoAlarma() {
        if (mediaPlayer == null) {
            val sonidoDefecto = android.media.RingtoneManager.getDefaultUri(android.media.RingtoneManager.TYPE_ALARM)
                ?: android.media.RingtoneManager.getDefaultUri(android.media.RingtoneManager.TYPE_NOTIFICATION)

            mediaPlayer = MediaPlayer.create(this, sonidoDefecto)?.apply {
                isLooping = true
                start()
            }
        }
    }

    private fun detenerSonidoAlarma() {
        mediaPlayer?.let {
            if (it.isPlaying) {
                it.stop()
            }
            it.release()
            mediaPlayer = null
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        detenerSonidoAlarma()
    }
}